﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items.Weapons
{
    public class Crossbow : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crossbow");
            Tooltip.SetDefault("Requires Tinkerer's Workbench. Transforms wooden arrows into high-velocity crossbow bolts");
        }
        public override void SetDefaults()
        {
            item.damage = 185;
            item.crit = item.crit + 25;
            item.ranged = true;
            item.width = 64;
            item.height = 25;
            item.maxStack = 1;
            item.useTime = 35;
            item.useAnimation = 36;
            item.useStyle = 5;
            item.knockBack = 11;
            item.value = 100000;
            item.rare = 8;
            item.UseSound = SoundID.Item5;
            item.noMelee = true;
            item.shoot = 3;
            item.useAmmo = AmmoID.Arrow;
            item.shootSpeed = 2000000f;
            item.autoReuse = false;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.SniperRifle, 1);
            recipe.AddTile(TileID.TinkerersWorkbench);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}