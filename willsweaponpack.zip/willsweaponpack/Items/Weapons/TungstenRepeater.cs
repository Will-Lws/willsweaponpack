using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items.Weapons
{
	public class TungstenRepeater : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Tungsten Repeater");
			Tooltip.SetDefault("Faster rate of fire but less damage");
		}
		public override void SetDefaults()
		{
            item.damage = 3;
            item.ranged = true;
            item.width = 56;
            item.height = 20;
            item.maxStack = 1;
            item.useTime = 18;
            item.useAnimation = 19;
            item.useStyle = 5;
            item.knockBack = 0;
            item.value = 1050;
            item.rare = 0;
            item.UseSound = SoundID.Item5;
            item.noMelee = true;
            item.shoot = 1;
            item.useAmmo = AmmoID.Arrow;
            item.shootSpeed = 6F;
            item.autoReuse = true;
        }

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.TungstenBar, 7);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
