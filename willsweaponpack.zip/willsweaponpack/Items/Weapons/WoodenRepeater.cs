using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items.Weapons
{
	public class WoodenRepeater : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Wooden Repeater");
			Tooltip.SetDefault("Faster rate of fire but less damage.");
		}
		public override void SetDefaults()
		{
            item.damage = 1;
            item.ranged = true;
            item.width = 56;
            item.height = 20;
            item.maxStack = 1;
            item.useTime = 20;
            item.useAnimation = 19;
            item.useStyle = 5;
            item.knockBack = 0;
            item.value = 20;
            item.rare = 0;
            item.UseSound = SoundID.Item5;
            item.noMelee = true;
            item.shoot = 1;
            item.useAmmo = AmmoID.Arrow;
            item.shootSpeed = 6;
            item.autoReuse = true;
        }

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Wood, 10);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
