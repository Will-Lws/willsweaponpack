using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items.Weapons
{
	public class MeteorRepeater : ModItem
	{
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Meteor Repeater");
            Tooltip.SetDefault("25% Chance not to consume ammo" +
                "Hey, it rhymes?");
        }
        public override void SetDefaults()
		{
            item.damage = 8;
            item.noMelee = true;
            item.ranged = true;
            item.width = 56;
            item.height = 20;
            item.useTime = 10;
            item.useAnimation = 19;
            item.maxStack = 1;
            item.useStyle = 5;
            item.shoot = 1;
            item.knockBack = 1;
            item.value = 50000;
            item.rare = 3;
            item.UseSound = SoundID.Item5;
            item.useAmmo = AmmoID.Arrow;
            item.autoReuse = true;
            item.shootSpeed = 7f;

        }
        public override bool ConsumeAmmo(Player player)
        {
            return Main.rand.NextFloat() >= .25f;
        }


		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.MeteoriteBar, 20);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
