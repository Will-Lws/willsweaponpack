using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items.Weapons
{
	public class OPAutoRepeater : ModItem
	{
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("OP Auto-Repeater");
            Tooltip.SetDefault("Say to yourself: I love OPness");
        }
        public override void SetDefaults()
		{
            item.damage = 100;
            item.crit = item.crit + 96;
            item.noMelee = true;
            item.ranged = true;
            item.width = 56;
            item.height = 20;
            item.useTime = 1;
            item.useAnimation = 19;
            item.maxStack = 1;
            item.useStyle = 5;
            item.shoot = 1;
            item.knockBack = 0;
            item.value = 50000;
            item.rare = 10;
            item.UseSound = SoundID.Item5;
            item.useAmmo = AmmoID.Arrow;
            item.autoReuse = true;
            item.shootSpeed = 1000f;

        }
        public override bool ConsumeAmmo(Player player)
        {
            return Main.rand.NextFloat() >= .99f;
        }
        public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Wood, 1);
            recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
