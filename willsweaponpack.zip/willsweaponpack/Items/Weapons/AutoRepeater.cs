using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items.Weapons
{
	public class AutoRepeater : ModItem
	{
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Auto-Repeater");
            Tooltip.SetDefault("Ra-tatatatatahhhh..." +
                "Has large spread and 75% chance not to consume ammo");
        }
        public override void SetDefaults()
		{
            item.damage = 14;
            item.noMelee = true;
            item.ranged = true;
            item.width = 56;
            item.height = 20;
            item.useTime = 3;
            item.useAnimation = 19;
            item.maxStack = 1;
            item.useStyle = 5;
            item.shoot = 1;
            item.knockBack = 0;
            item.value = 50000;
            item.rare = 5;
            item.UseSound = SoundID.Item5;
            item.useAmmo = AmmoID.Arrow;
            item.autoReuse = true;
            item.shootSpeed = 14f;

        }
        public override bool ConsumeAmmo(Player player)
        {
            return Main.rand.NextFloat() >= .75f;
        }
        public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.HallowedRepeater, 1);
            recipe.AddIngredient(ItemID.Minishark, 1);
            recipe.AddIngredient(ItemID.IronBar, 50);
            recipe.AddIngredient(ItemID.Wood, 50);
            recipe.AddIngredient(ItemID.LightShard, 1);
            recipe.AddIngredient(ItemID.DarkShard, 1);
            recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
