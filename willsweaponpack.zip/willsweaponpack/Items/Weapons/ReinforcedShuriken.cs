using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items.Weapons
{
	public class ReinforcedShuriken : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Reinforced Shuriken");
			Tooltip.SetDefault("Improved shuriken");
		}
		public override void SetDefaults()
		{
            item.useStyle = 1;
            item.shootSpeed = 13f;
            //item.shoot = ProjectileType("Shuriken");
            item.damage = 12;
            item.crit = item.crit + 5;
            item.width = 26;
            item.height = 26;
            item.maxStack = 999;
            item.consumable = true;
            item.UseSound = SoundID.Item1;
            item.useAnimation = 15;
            item.useTime = 12;
            item.noUseGraphic = true;
            item.noMelee = true;
            item.value = 60;
            item.thrown = true;
              
        }

		public override void AddRecipes()
		{
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.IronBar, 1);
            recipe.AddIngredient(ItemID.Shuriken, 50);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this, 50);
            recipe.AddRecipe();
        }
	}
}
