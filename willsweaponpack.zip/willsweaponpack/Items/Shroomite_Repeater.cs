using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items
{
	public class Shroomite_Repeater : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Shroomite Repeater");
			Tooltip.SetDefault("This is a modded bow.");
		}
		public override void SetDefaults()
		{
            item.damage = 72;
            item.ranged = true;
            item.width = 54;
            item.height = 24;
            item.maxStack = 1;
            item.useTime = 13;
            item.useAnimation = 19;
            item.useStyle = 5;
            item.knockBack = 4;
            item.value = 300000;
            item.rare = 8;
            item.UseSound = SoundID.Item5;
            item.noMelee = true;
            item.shoot = 1;
            item.useAmmo = AmmoID.Arrow;
            item.shootSpeed = 18f;
            item.autoReuse = true;
        }

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.ShroomiteBar, 12);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
