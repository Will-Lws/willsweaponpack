using Terraria.ID;
using Terraria.ModLoader;

namespace willsweaponpack.Items
{
	public class Meteor_Repeater : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Meteor Repeater");
			Tooltip.SetDefault("This is a modded bow.");
		}
		public override void SetDefaults()
		{
            item.damage = 15;
            item.ranged = true;
            item.width = 56;
            item.height = 20;
            item.maxStack = 1;
            item.useTime = 5;
            item.useAnimation = 19;
            item.useStyle = 5;
            item.knockBack = 1;
            item.value = 100000;
            item.rare = 5;
            item.UseSound = SoundID.Item5;
            item.noMelee = true;
            item.shoot = 1;
            item.useAmmo = AmmoID.Arrow;
            item.shootSpeed = 8f;
            item.autoReuse = true;
        }

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.ShroomiteBar, 12);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
