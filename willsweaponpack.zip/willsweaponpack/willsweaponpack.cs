using Terraria.ModLoader;

namespace willsweaponpack
{
	class willsweaponpack : Mod
	{
		public willsweaponpack()
		{
		}
	}
}
